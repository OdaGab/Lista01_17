package com.example.lista01_02
import android.annotation.SuppressLint
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.example.lista01_02.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    private lateinit var binding : ActivityMainBinding

    @SuppressLint("SetTextI18n")
    override fun onCreate(savedInstanceState: Bundle?) {
        binding = ActivityMainBinding.inflate(layoutInflater)
        super.onCreate(savedInstanceState)

        setContentView(binding.root)

        binding.btnok.setOnClickListener{
                    val texto = binding.edttxtNome.text.toString()

                    if(texto.isEmpty()){
                        binding.edttxtNome.setText("Preencha os campos!")
                        binding.edttxtNome.setTextColor(getColor(R.color.vermelho))
                    }else{
                        binding.textboasvindas.text = "Seja Bem Vindo!"
                        binding.textresultado.setTextColor(getColor(R.color.vermelho))
                        binding.textresultado.setText(texto.uppercase()).toString()
                    }
                }
    }
}