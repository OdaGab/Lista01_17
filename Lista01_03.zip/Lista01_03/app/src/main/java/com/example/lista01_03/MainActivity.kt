package com.example.lista01_03

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.example.lista01_03.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {

        super.onCreate(savedInstanceState)

        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.btnok.setOnClickListener{

           val nome = binding.edttxtNome.text.toString()
            val salario = binding.edttxtSalario.text.toString()

            binding.textMostraNome.setText(nome.uppercase()).toString()
            binding.texMostraSalario.setText(salario.uppercase()).toString()


        }

    }
}